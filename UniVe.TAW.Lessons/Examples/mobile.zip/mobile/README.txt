To build/run the application for Android platform:

$ npm install
$ cordova platform add android
$ cd src
$ npm install
$ ng build
$ cd ..
$ cordova build android
$ cordova run android


